package com.app.glossa_v2.helpers

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Window
import android.widget.ImageView
import com.airbnb.lottie.LottieAnimationView
import com.app.glossa_v2.R

class recordingDialog {

    fun showResetPasswordDialog(activity: Activity){
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.custom_dialog)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val dialogBack  = dialog.findViewById<ImageView>(R.id.back)
        val dialogMic = dialog.findViewById<LottieAnimationView>(R.id.animation)

        dialogBack.setOnClickListener {
            dialog.dismiss()
        }

        dialogMic.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
}