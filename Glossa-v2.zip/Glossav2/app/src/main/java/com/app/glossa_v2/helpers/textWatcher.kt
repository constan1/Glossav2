package com.app.glossa_v2.helpers

import android.text.Editable
import android.text.TextWatcher

abstract class textWatcher: TextWatcher {

    var isEmpty: Boolean = true

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if(s!!.isEmpty()){
            isEmpty =  true
            onEmpty(true)
        }
        else if (isEmpty){
            isEmpty = false
            onEmpty(false)
        }
    }

    override fun afterTextChanged(s: Editable?) {
        TODO("Not yet implemented")
    }

    abstract fun onEmpty(empty: Boolean)
}